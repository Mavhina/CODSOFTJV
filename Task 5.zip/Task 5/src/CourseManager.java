import javafx.beans.property.*;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.sql.*;
import java.util.Random;

/**
 * 
 * @author mavhinamulisa
 * @version Task 05
 */

public class CourseManager {
    private ObservableList<Course> availableCourses = FXCollections.observableArrayList();
    private ObservableList<Course> registeredCourses = FXCollections.observableArrayList();

    private final String dbUrl;
    private final String dbUser;
    private final String dbPassword;
    private String studentNumber;

    public CourseManager(String dbUrl, String dbUser, String dbPassword) {
        this.dbUrl = dbUrl;
        this.dbUser = dbUser;
        this.dbPassword = dbPassword;
        loadCoursesFromDatabase();
    }

    public TableView<Course> createCourseTable(String title) {
        TableView<Course> table = new TableView<>();
        table.setEditable(false);

        TableColumn<Course, String> codeCol = new TableColumn<>("Code");
        codeCol.setCellValueFactory(new PropertyValueFactory<>("code"));
        codeCol.setMinWidth(50);

        TableColumn<Course, String> titleCol = new TableColumn<>("Title");
        titleCol.setCellValueFactory(new PropertyValueFactory<>("title"));
        titleCol.setMinWidth(150);

        TableColumn<Course, String> descriptionCol = new TableColumn<>("Description");
        descriptionCol.setCellValueFactory(new PropertyValueFactory<>("description"));
        descriptionCol.setMinWidth(330);

        TableColumn<Course, Integer> capacityCol = new TableColumn<>("Capacity");
        capacityCol.setCellValueFactory(new PropertyValueFactory<>("capacity"));
        capacityCol.setMinWidth(70);

        TableColumn<Course, String> scheduleCol = new TableColumn<>("Schedule");
        scheduleCol.setCellValueFactory(new PropertyValueFactory<>("schedule"));
        scheduleCol.setMinWidth(190);

        table.getColumns().addAll(codeCol, titleCol, descriptionCol, capacityCol, scheduleCol);
        table.setItems(getCourses(title));

        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        table.setMinWidth(800);

        return table;
    }

    public ObservableList<Course> getCourses(String title) {
        return "Available Courses".equals(title) ? availableCourses : registeredCourses;
    }

    private void saveStudentToDatabase(String studentNumber, String fullName, String courseCode) {
        String insertQuery = "INSERT INTO students (StudentID, name, registered_course) VALUES (?, ?, ?)";

        try (Connection connection = DriverManager.getConnection(dbUrl, dbUser, dbPassword);
             PreparedStatement preparedStatement = connection.prepareStatement(insertQuery)) {

            preparedStatement.setInt(1, Integer.parseInt(studentNumber));
            preparedStatement.setString(2, fullName);
            preparedStatement.setString(3, courseCode);

            preparedStatement.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Database Error", "Failed to save student information to the database.");
        }
    }

    public void registerCourse(TextField fullNameField, TextField contactNumberField, TextField emailField,
                               TableView<Course> availableTable, TableView<Course> registeredTable) {
        String fullName = fullNameField.getText();
        String contactNumber = contactNumberField.getText();
        String email = emailField.getText();

        if (fullName.isEmpty() || contactNumber.isEmpty() || email.isEmpty()) {
            showAlert("Registration Error", "Please provide all required information.");
            return;
        }

        Course selectedCourse = availableTable.getSelectionModel().getSelectedItem();

        if (selectedCourse != null) {
            if (selectedCourse.getCapacity() > 0) {
                selectedCourse.setCapacity(selectedCourse.getCapacity() - 1);
                selectedCourse.setRegisteredUser(new User(fullName, contactNumber, email, studentNumber));

                String studentNumber = generateStudentNumber();
                saveStudentToDatabase(studentNumber, fullName, selectedCourse.getCode());

                registeredCourses.add(selectedCourse);

                showAlert("Registration Successful",
                        "You have successfully registered for the course.\nYour Student Number: " + studentNumber);

            } else {
                showAlert("Registration Error", "Course is full. Cannot register.");
            }
        } else {
            showAlert("Selection Error", "Please select a course to register.");
        }
    }

    public void removeCourse(TableView<Course> registeredTable) {
        Course selectedCourse = registeredTable.getSelectionModel().getSelectedItem();
        if (selectedCourse != null) {
            selectedCourse.setCapacity(selectedCourse.getCapacity() + 1);
            registeredCourses.remove(selectedCourse);
            availableCourses.add(selectedCourse);
        } else {
            showAlert("Selection Error", "Please select a registered course to remove.");
        }
    }

    public void loadCoursesFromDatabase() {
        try (Connection connection = DriverManager.getConnection(dbUrl, dbUser, dbPassword)) {
            String query = "SELECT * FROM courses";
            try (Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery(query)) {

                while (resultSet.next()) {
                    String code = resultSet.getString("code");
                    String title = resultSet.getString("title");
                    String description = resultSet.getString("description");
                    int capacity = resultSet.getInt("capacity");
                    String schedule = resultSet.getString("schedule");

                    Course course = new Course(code, title, description, capacity, schedule);
                    availableCourses.add(course);
                }

            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Database Error", "Failed to load course data from the database.");
        }
    }

    private String generateStudentNumber() {
        Random random = new Random();
        int randomDigits = 10000 + random.nextInt(90000);
        studentNumber = "2024" + randomDigits;
        return studentNumber;
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static class Course {
        private final StringProperty code;
        private final StringProperty title;
        private final StringProperty description;
        private final IntegerProperty capacity;
        private final StringProperty schedule;
        private User registeredUser;

        public Course(String code, String title, String description, int capacity, String schedule) {
            this.code = new SimpleStringProperty(code);
            this.title = new SimpleStringProperty(title);
            this.description = new SimpleStringProperty(description);
            this.capacity = new SimpleIntegerProperty(capacity);
            this.schedule = new SimpleStringProperty(schedule);
        }

        public String getCode() {
            return code.get();
        }

        public String getTitle() {
            return title.get();
        }

        public String getDescription() {
            return description.get();
        }

        public int getCapacity() {
            return capacity.get();
        }

        public void setCapacity(int capacity) {
            this.capacity.set(capacity);
        }

        public String getSchedule() {
            return schedule.get();
        }

        public StringProperty codeProperty() {
            return code;
        }

        public StringProperty titleProperty() {
            return title;
        }

        public StringProperty descriptionProperty() {
            return description;
        }

        public IntegerProperty capacityProperty() {
            return capacity;
        }

        public StringProperty scheduleProperty() {
            return schedule;
        }

        public User getRegisteredUser() {
            return registeredUser;
        }

        public void setRegisteredUser(User registeredUser) {
            this.registeredUser = registeredUser;
        }
    }

    public static class User {
        private final String fullName;
        private final String contactNumber;
        private final String email;
        private final String studentNumber;

        public User(String fullName, String contactNumber, String email, String studentNumber) {
            this.fullName = fullName;
            this.contactNumber = contactNumber;
            this.email = email;
            this.studentNumber = studentNumber;
        }
        
        public String getStudentNumber() {
            return studentNumber;
        }

        public String getFullName() {
            return fullName;
        }

        public String getContactNumber() {
            return contactNumber;
        }

        public String getEmail() {
            return email;
        }
    }
}
