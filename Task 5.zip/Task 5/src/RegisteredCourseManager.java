import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.Alert;
import javafx.scene.control.TableView;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * 
 * @author mavhinamulisa
 * @version Task 05
 */
public class RegisteredCourseManager {
    private ObservableList<CourseManager.Course> registeredCourses = FXCollections.observableArrayList();

    private final String dbUrl;
    private final String dbUser;
    private final String dbPassword;

    public RegisteredCourseManager(String dbUrl, String dbUser, String dbPassword) {
        this.dbUrl = dbUrl;
        this.dbUser = dbUser;
        this.dbPassword = dbPassword;
        loadRegisteredCoursesFromDatabase();
    }

    public TableView<CourseManager.Course> createRegisteredCourseTable(String studentNumber) {
        TableView<CourseManager.Course> table = new TableView<>();
        // Retrieve student information and display registered courses
        getStudentInfoAndDisplayCourses(studentNumber, table);
        
        return table;
    }
    
    //To retrieve course content
    private CourseManager.Course getCourseDetails(String courseCode) {
        try (Connection connection = DriverManager.getConnection(dbUrl, dbUser, dbPassword)) {
            String query = "SELECT * FROM courses WHERE code = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setString(1, courseCode);
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    if (resultSet.next()) {
                        String code = resultSet.getString("code");
                        String title = resultSet.getString("title");
                        String description = resultSet.getString("description");
                        int capacity = resultSet.getInt("capacity");
                        String schedule = resultSet.getString("schedule");

                        return new CourseManager.Course(code, title, description, capacity, schedule);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Database Error", "Failed to fetch course details from the database.");
        }

        return null;
    }
    
    //To remove student from the database
    public void removeStudent(String studentNumber) {
        try (Connection connection = DriverManager.getConnection(dbUrl, dbUser, dbPassword)) {
            String deleteQuery = "DELETE FROM students WHERE StudentID = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(deleteQuery)) {
                preparedStatement.setInt(1, Integer.parseInt(studentNumber));
                int rowsAffected = preparedStatement.executeUpdate();

                if (rowsAffected > 0) {
                    showAlert("Student Removed", "Student with Student Number " + studentNumber + " has been removed.");
                } else {
                    showAlert("Error", "Student with Student Number " + studentNumber + " not found.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Database Error", "Failed to remove student information from the database.");
        }
    }

    //To get student and course info from the database
    private void getStudentInfoAndDisplayCourses(String studentNumber, TableView<CourseManager.Course> table) {
        try (Connection connection = DriverManager.getConnection(dbUrl, dbUser, dbPassword)) {
            String studentQuery = "SELECT * FROM students WHERE StudentID = ?";
            try (PreparedStatement studentStatement = connection.prepareStatement(studentQuery)) {
                studentStatement.setInt(1, Integer.parseInt(studentNumber));
                try (ResultSet studentResultSet = studentStatement.executeQuery()) {
                    if (studentResultSet.next()) {
                        // Retrieve information from the result set
                        String fullName = studentResultSet.getString("name");
                        String courseCode = studentResultSet.getString("registered_course");

                        // Display student information
                        showAlert("Student Information", "Student Number: " + studentNumber + "\nFull Name: " + fullName + "\nRegistered Course: " + courseCode);

                        // Display registered courses
                        displayRegisteredCourses(courseCode, table);
                    } else {
                        showAlert("Error", "Student not found in the database.");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Database Error", "Failed to retrieve student information from the database.");
        }
    }

    
    
    private void displayRegisteredCourses(String studentNumber, TableView<CourseManager.Course> table) {
        ObservableList<CourseManager.Course> registeredCourses = FXCollections.observableArrayList();

        try (Connection connection = DriverManager.getConnection(dbUrl, dbUser, dbPassword)) {
            String query = "SELECT * FROM students WHERE student_number = ?";
            try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                preparedStatement.setInt(1, Integer.parseInt(studentNumber));
                try (ResultSet resultSet = preparedStatement.executeQuery()) {
                    while (resultSet.next()) {
                        String courseCode = resultSet.getString("registered_course");
                        // Fetch additional information about the course from the courses table
                        CourseManager.Course course = getCourseDetails(courseCode);
                        registeredCourses.add(course);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Database Error", "Failed to load registered courses from the database.");
        }

        // Set the items in the table
        table.setItems(registeredCourses);
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void loadRegisteredCoursesFromDatabase() {
        try (Connection connection = DriverManager.getConnection(dbUrl, dbUser, dbPassword)) {
            String query = "SELECT * FROM registered_courses";
            try (Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery(query)) {

                while (resultSet.next()) {
                    String code = resultSet.getString("code");
                    String title = resultSet.getString("title");
                    String description = resultSet.getString("description");
                    int capacity = resultSet.getInt("capacity");
                    String schedule = resultSet.getString("schedule");

                    // You may need to modify the constructor based on your Course class
                    CourseManager.Course course = new CourseManager.Course(code, title, description, capacity, schedule);
                    registeredCourses.add(course);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Database Error", "Failed to load registered course data from the database.");
        }
    }
}
