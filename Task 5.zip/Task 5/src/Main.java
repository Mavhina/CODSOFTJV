import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

/**
 * 
 * @author mavhinamulisa
 * @version Task 5
 */
public class Main extends Application {
    private CourseManager courseManager;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Course Registration System");

        // Initialize the CourseManager with database connection
        courseManager = new CourseManager("jdbc:mysql://127.0.0.1:3306/course_database", "root", "Mavhina123");

        // Create UI components
        TableView<CourseManager.Course> availableCoursesTable = courseManager.createCourseTable("Available Courses");
        TableView<CourseManager.Course> registeredCoursesTable = courseManager.createCourseTable("Registered Courses");

        Button registerButton = new Button("Register");
        Button removeButton = new Button("Remove");

        // Create user information fields
        TextField fullNameField = new TextField();
        TextField contactNumberField = new TextField();
        TextField emailField = new TextField();

        // Create student number input field
        Label studentNumberLabel = new Label("Student Number:");
        TextField studentNumberField = new TextField();

        // Create the button to show student information
        Button showStudentButton = new Button("Show Student Information");

        // Set event handlers
        registerButton.setOnAction(e -> courseManager.registerCourse(
                fullNameField, contactNumberField, emailField, availableCoursesTable, registeredCoursesTable));
        //removeButton.setOnAction(e -> courseManager.removeCourse(registeredCoursesTable));
        removeButton.setOnAction(e -> {
        	
            String studentNumberToRemove = studentNumberField.getText();
            
            try (Connection connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/course_database", "root", "Mavhina123")) {
                String deleteQuery = "DELETE FROM students WHERE StudentID = ?";
                try (PreparedStatement preparedStatement = connection.prepareStatement(deleteQuery)) {
                    preparedStatement.setInt(1, Integer.parseInt(studentNumberToRemove));
                    int rowsAffected = preparedStatement.executeUpdate();

                    if (rowsAffected > 0) {
                        //showAlert("Student Removed", "Student with Student Number " + studentNumberToRemove + " has been removed.");
                    } else {
                       // showAlert("Error", "Student with Student Number " + studentNumberToRemove + " not found.");
                    }
                }
            } catch (SQLException e1) {
                e1.printStackTrace();
            }
            
            courseManager.removeCourse(registeredCoursesTable);
        });

        // Create layout
        GridPane gridPane = new GridPane();
        gridPane.setHgap(10);
        gridPane.setVgap(10);

        gridPane.add(availableCoursesTable, 0, 0);
        gridPane.add(registeredCoursesTable, 1, 0);

        HBox userFields = new HBox(10);
        userFields.getChildren().addAll(
                new Label("Full Name:"),
                fullNameField,
                new Label("Contact Number:"),
                contactNumberField,
                new Label("Email:"),
                emailField
        );
        gridPane.add(userFields, 0, 1, 2, 1);

        HBox studentNumberBox = new HBox(10);
        studentNumberBox.getChildren().addAll(
                studentNumberLabel,
                studentNumberField,
                showStudentButton
        );
        gridPane.add(studentNumberBox, 1, 1);

        gridPane.add(registerButton, 0, 2);
        gridPane.add(removeButton, 1, 2);

        // Create scene
        Scene scene = new Scene(gridPane, 800, 500); // Increased width and height
        primaryStage.setScene(scene);

        // Show the stage
        primaryStage.show();
    }
}
